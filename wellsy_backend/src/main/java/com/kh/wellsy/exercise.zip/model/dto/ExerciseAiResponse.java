package com.kh.wellsy.exercise.model.dto;

import java.math.BigDecimal;

public class ExerciseAiResponse {

    private String exerciseName;
    private String amountDescription;
    private String exerciseType;
    private String difficulty;
    private Integer durationMinutes;
    private Integer count;
    private BigDecimal caloriesPerMinute;
    private BigDecimal estimatedCalories;

    public ExerciseAiResponse() {}

    public String getExerciseName() {
        return exerciseName;
    }

    public void setExerciseName(String exerciseName) {
        this.exerciseName = exerciseName;
    }

    public String getAmountDescription() {
        return amountDescription;
    }

    public void setAmountDescription(String amountDescription) {
        this.amountDescription = amountDescription;
    }

    public String getExerciseType() {
        return exerciseType;
    }

    public void setExerciseType(String exerciseType) {
        this.exerciseType = exerciseType;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public Integer getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(Integer durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public BigDecimal getCaloriesPerMinute() {
        return caloriesPerMinute;
    }

    public void setCaloriesPerMinute(BigDecimal caloriesPerMinute) {
        this.caloriesPerMinute = caloriesPerMinute;
    }

    public BigDecimal getEstimatedCalories() {
        return estimatedCalories;
    }

    public void setEstimatedCalories(BigDecimal estimatedCalories) {
        this.estimatedCalories = estimatedCalories;
    }
}